# AdsPro Deployment Guide (Hostinger)

## Server Info
- **Host**: `89.117.7.38:65002`
- **User**: `u695160153`
- **Password**: `@@Marote1989`
- **App path**: `/home/u695160153/domains/luxom.com.ar/public_html/adsmanager/`
- **Database**: `u695160153_admanager` (localhost, user `u695160153_admanager`, pass `@@$$Derplast0102`)

## Initial Setup (Done)
1. Created `adsmanager` directory in `public_html`.
2. Copied Laravel source (excluding `vendor`, `node_modules`).
3. Fixed empty APP_KEY in `.env`.
4. Created cache directories and set permissions.
5. Moved `public/` contents to root (Hostinger requires index.php in root).
6. Created symlink `adspro` → `adsmanager` for installer compatibility.
7. Ran `install.php` (created DB tables, admin user).
8. Fixed "Vite manifest not found" with symlink `public` → `.`.
9. Fixed missing `sessions` table via migration.
10. Changed `CACHE_DRIVER` to `file` to avoid `cache` table.
11. Updated `licensed.php` for demo license (valid until 2030-12-31).
12. Renamed `/config` route to `/settings` to avoid LiteSpeed block.
13. Edited middleware `CheckLicense.php` and `CheckModuleAccess.php` for "grace mode".
14. Hardcoded Evolution API credentials in `config/adspro.php`.
15. Applied updates from ZIPs (`update-meta-wa---*.zip`, `adspro-source_2---*.zip`).
16. Created `app_settings` table manually.
17. Fixed CSRF 419 by adding `<meta name="csrf-token">` to `app.blade.php`.
18. Updated `ConfigController.php` and `MetaAuthController.php` for resilience.

## Current Status
- ✅ App accessible at `https://adsmanager.luxom.com.ar`
- ✅ Admin login works (admin@adspro.com / admin)
- ✅ `/settings` loads without errors
- ✅ WhatsApp QR scanning works (CSRF fixed)
- ❌ Meta Ads: frontend shows "Conectar con Meta" instead of "Configurar Meta App" (awaiting updated build from developer)

## Pending
- Receive updated `public/build/` from developer (with modal for Meta config).
- Insert real Meta App ID and App Secret via modal.
- Test `/analytics` IA module.

## Git Repository
Local repo at `/data/.openclaw/workspace/adsmanager-git`. Contains all source files except `vendor` and `node_modules`. Committed fixes for CSRF and Meta resilience.

## Troubleshooting
- **Vite manifest not found**: Ensure `public/build/manifest.json` exists. Recompile assets locally and upload entire `public/build/`.
- **CSRF 419**: Verify `<meta name="csrf-token">` present in `app.blade.php`.
- **Table missing**: Create manually via SQL or run migrations (if `artisan` exists).
- **Meta redirects with empty client_id**: `app_settings` table empty. Insert `meta_app_id` and `meta_app_secret` (encrypted).