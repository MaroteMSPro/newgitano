# 📦 RESUMEN COMPLETO DEL WORKSPACE OPENCLAW

**Fecha:** 2026-04-16  
**Host:** Docker container 2175b0e43748  
**Ubicación:** `/data/.openclaw/workspace`

---

## 🎯 PROYECTOS ACTIVOS

### 1. **El Gitano CRM** (EN CURSO)
**Objetivo:** Migrar CRM a v2gitano.luxom.com.ar con 5 cambios funcionales y corregir problemas CSS/layout/autenticación.

**Estado actual:**
- ✅ Frontend v19 compilado y desplegado en `v2gitano.luxom.com.ar`
- ✅ Backend parcheado (`CRMController.php`) para enviar audio/imágenes/videos/documentos via Evolution API
- ✅ 5 cambios funcionales implementados:
  1. Etiquetas privadas
  2. Renombrar cliente
  3. Drag&drop archivos
  4. Fecha en mensajes
  5. Grabación de audio
- ❌ Pendiente: Verificar envío de imágenes/videos (backend parcheado, frontend listo)

**Archivos clave:**
- Frontend: `/elgitano-frontend/` (Vue.js 3 + Vite)
- Backend parche: `/CRMController.php` (descargado del servidor y modificado)
- Repo Git: `newgitano/` (https://github.com/MaroteMSPro/newgitano)
- Versiones fuente: `elgitano-v18-source/`, `elgitano-v19-source/`, `elgitano-v20-source/`

**Acceso SSH al servidor:**
- Host: `89.117.7.38:65002`
- User: `u695160153`
- Pass: `@@Luxom00102`
- Ruta: `/home/u695160153/domains/luxom.com.ar/public_html/v2gitano/`

---

### 2. **AdsManager / AdsPro** (COMPLETADO)
**Objetivo:** Desplegar sistema de gestión de anuncios Meta Ads con Evolution API.

**Estado actual:**
- ✅ App desplegada en `https://adsmanager.luxom.com.ar`
- ✅ Admin login funcional (admin@adspro.com / admin)
- ✅ WhatsApp QR scanning funcionando
- ✅ CSRF 419 corregido
- ❌ Meta Ads: frontend muestra "Conectar con Meta" en lugar de "Configurar Meta App" (necesita build actualizado)

**Archivos clave:**
- Código fuente: `/adsmanager-git/` (repo Git local)
- Build desplegado: `/adsmanager/` (Laravel)
- Documentación: `DEPLOY.md` (credenciales SSH y pasos)

**Acceso SSH:**
- Mismo servidor que El Gitano
- Ruta: `/home/u695160153/domains/luxom.com.ar/public_html/adsmanager/`

---

### 3. **MSPro Mobile** (EN PAUSA)
**Objetivo:** Debuggear login de cliente Android para servidor Mu Online.

**Estado actual:**
- ✅ Greeting decrypts correctamente
- ✅ TickCount fix aplicado
- ❌ Server no responde al login packet
- **Root cause:** Mobile recibe formato de greeting diferente a MainNew (PC)

**Archivos clave:**
- Código fuente: `/MSPro-Mobile/` (Android C++)
- Referencia: `/MSPro-MainNew/` (PC client)
- Análisis: `MEMORY.md` y `memory/v480-final-status.md`

---

## 📁 ESTRUCTURA DEL WORKSPACE

```
/data/.openclaw/workspace/
├── AGENTS.md              # Guía de uso del workspace
├── SOUL.md                # Personalidad del agente
├── USER.md                # Perfil del usuario (Pache)
├── IDENTITY.md            # Identidad del agente (Betapache)
├── MEMORY.md              # Memoria a largo plazo
├── TOOLS.md               # Notas locales de herramientas
├── DEPLOY.md              # Credenciales SSH y guías de deploy
├── HEARTBEAT.md           # Tareas periódicas (vacío)
├── BOOT.md                # Instrucciones de inicio
├── memory/                # Notas diarias (2026-04-*.md)
│
├── elgitano-frontend/     # Frontend Vue.js 3 de El Gitano
│   ├── src/               # Código fuente
│   ├── dist/              # Build compilado
│   ├── AUDIO_BACKEND_PATCH.md
│   └── BACKEND_FIXES.md
│
├── elgitano-v20-source/   # Última versión fuente (v20)
├── elgitano-v19-source/   # Versión anterior
├── elgitano-v18-source/   # Versión base
│
├── newgitano/             # Repositorio Git organizado
│   ├── frontend/
│   ├── backend/
│   ├── docs/
│   └── README.md
│
├── adsmanager-git/        # Código fuente AdsManager (Git)
├── adsmanager/            # Build desplegado AdsManager
├── adspro-source*/        # Varias versiones de AdsPro
│
├── MSPro-Mobile/          # Cliente Android Mu Online
├── MSPro-MainNew/         # Cliente PC de referencia
│
└── [varios otros dirs]    # Builds temporales, pruebas, etc.
```

---

## 🔑 CREDENCIALES Y ACCESOS

### Servidor Luxom.com.ar
- **IP:** 89.117.7.38
- **Puerto SSH:** 65002
- **Usuario:** u695160153
- **Contraseña:** @@Luxom00102

### Bases de datos
- **El Gitano:** `u695160153_elgitano` (localhost)
- **AdsManager:** `u695160153_admanager` (localhost, user: `u695160153_admanager`, pass: `@@$$Derplast0102`)

### Accesos web
- El Gitano original: https://elgitano.luxom.com.ar
- El Gitano v2: https://v2gitano.luxom.com.ar
- AdsManager: https://adsmanager.luxom.com.ar

---

## 📝 TAREAS PENDIENTES

### El Gitano (URGENTE)
1. Verificar que el envío de imágenes/videos/documentos funcione con el parche backend
2. Coordinar con desarrollador backend para incluir `media_url` en mensajes salientes
3. Actualizar frontend a v20 si tiene mejoras en recordatorios

### AdsManager (BAJA PRIORIDAD)
1. Recibir build actualizado del desarrollador para Meta Ads modal
2. Insertar Meta App ID y App Secret via modal
3. Testear módulo `/analytics` IA

### MSPro Mobile (EN PAUSA)
1. Comparar byte-a-byte login packet Mobile vs MainNew
2. Verificar struct PMSG_CONNECT_ACCOUNT_SEND
3. Debuggear por qué server no responde

---

## 🔗 REPOSITORIOS GIT

### El Gitano
- **URL:** https://github.com/MaroteMSPro/newgitano
- **Token:** `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`
- **Estructura organizada:** frontend/, backend/, docs/, scripts/

### AdsManager
- **Repo local:** `/adsmanager-git/`
- **Contiene:** Todo el código fuente Laravel excepto vendor/node_modules
- **Commits:** Fixes para CSRF y Meta resilience

---

## 🧠 CONTEXTO DE MEMORIA

### Decisiones clave:
1. **Problema CSS El Gitano:** Selectores con atributos scoped `[data-v-XXXXXX]` no coincidían. Solución: eliminar todos esos atributos del CSS.
2. **Problema autenticación:** Contraseña de `admin` actualizada a `$$elgitano001` (hash bcrypt).
3. **Problema botón 🎤:** Error de posicionamiento CSS. Fix: ocultar en `chat-search`, mostrar en `chat-view-panel`.
4. **Problema archivos adjuntos:** Backend solo procesaba audio. Parche extendido para imágenes/videos/documentos.

### Lecciones aprendidas:
- Hostinger requiere `index.php` en root (no en `public/`)
- Evolution API usa `/message/sendMedia` para imágenes/videos/documentos
- Frontend Vue.js 3 necesita recargar mensajes del servidor si no recibe `msg_id`
- MySQL espera formato `YYYY-MM-DD HH:MM:SS` (no `YYYY-MM-DDTHH:MM`)

---

## 📊 ESTADO DE ARCHIVOS MODIFICADOS

### Modificados recientemente (2026-04-15):
1. `/elgitano-frontend/src/assets/styles.css` - Fix botón 🎤
2. `/elgitano-frontend/src/views/CRM.vue` - Mejoras en recordatorios (v20)
3. `/CRMController.php` - Parche completo para media
4. `/memory/2026-04-15.md` - Log de progreso

### Subidos al servidor:
1. `v2gitano.luxom.com.ar/app.html` (frontend v19)
2. `v2gitano.luxom.com.ar/assets/` (todos los chunks)
3. `v2gitano.luxom.com.ar/src/Controllers/CRMController.php` (parche backend)

---

## 🚀 INSTRUCCIONES PARA OTRA INSTANCIA OPENCLAW

Si otra instancia OpenClaw va a trabajar en **AdsManager**:

1. **Clonar repo local:** `cd /data/.openclaw/workspace && cp -r adsmanager-git/ /ruta/nueva/`
2. **Revisar DEPLOY.md** para credenciales SSH y pasos de deploy
3. **Acceder al servidor** con las credenciales de arriba
4. **Ruta de deploy:** `/home/u695160153/domains/luxom.com.ar/public_html/adsmanager/`
5. **Problema conocido:** Meta Ads necesita build actualizado con modal de configuración
6. **CSRF ya fixeado:** Ver `app.blade.php` y `ConfigController.php`

**Esta instancia seguirá trabajando en El Gitano CRM.**

---

## 📞 CONTACTO Y COORDINACIÓN

- **Usuario:** Pache (Nicolas Pacheco)
- **Timezone:** America/Sao_Paulo
- **Preferencias:** Trato descontracturado, buena onda, emojis OK
- **Canal actual:** Telegram (@7539312929)

---

*Documento generado automáticamente por Betapache 🛠️ el 2026-04-16*